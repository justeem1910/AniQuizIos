//
//  ItemLevelCVLCell.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 24/06/2021.
//

import UIKit

class ItemLevelCVLCell: UICollectionViewCell {
    @IBOutlet weak var imageBackground:UIImageView!
    @IBOutlet weak var labelName:UILabel!
    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
}
