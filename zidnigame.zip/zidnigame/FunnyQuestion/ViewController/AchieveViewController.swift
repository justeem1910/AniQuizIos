//
//  AchieveViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 22/07/2021.
//

import UIKit

class AchieveViewController: UIViewController {
    @IBOutlet weak var btn_close:UIImageView!
    @IBOutlet weak var imageBackground:UIImageView!
    @IBOutlet weak var imageback:UIImageView!
    @IBOutlet weak var imageStar1:UIImageView!
    @IBOutlet weak var imageStar2:UIImageView!
    @IBOutlet weak var imageStar3:UIImageView!
    
    @IBOutlet weak var labelText:UILabel!
    @IBOutlet weak var labelScore:UILabel!
    
    @IBOutlet weak var btn_Menu:UIButton!
    
    var numberQuestion:Int = UserDefaults.standard.integer(forKey: "achieveNumberQuestion")
    var numberCorrect:Int = UserDefaults.standard.integer(forKey: "achieveCorrect")
    var checkCorrect:Double = 0.0
    
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkCorrect = Double(numberCorrect) * 1.5
        if numberQuestion == 0 {
            imageStar1.isHidden = true
            imageStar2.isHidden = true
            imageStar3.isHidden = true
        }else if 2*numberCorrect < numberQuestion {
            imageStar2.isHidden = false
        } else if 2*numberCorrect >= numberQuestion && checkCorrect < Double(numberQuestion) {
            imageStar1.isHidden = false
            imageStar2.isHidden = false
        } else{
            imageStar1.isHidden = false
            imageStar2.isHidden = false
            imageStar3.isHidden = false
        }
        
        labelScore.text = "\(numberCorrect)/\(numberQuestion)"
        if UIDevice.current.userInterfaceIdiom == .pad{
            
            let heightConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            let withConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            imageback.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_close.addConstraints([ heightConstraintClose, withConstraintClose])
            
            let horizontalConstraintStar1 = NSLayoutConstraint(item: imageStar1 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.75, constant: 0)
            view.addConstraint(horizontalConstraintStar1)
            let verticalConstraintStar3 = NSLayoutConstraint(item: imageStar3 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.25, constant: 0)
            view.addConstraint(verticalConstraintStar3)
            
            
            let heightConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_Menu.addConstraints([ heightConstraintMenu, withConstraintMenu])
            
            labelScore.font = UIFont(name: "Arial Bold", size: 85)
            labelText.font = UIFont(name: "Chalkboard SE Bold", size: 33)
            
            
        } else{
            let heightConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageback.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            btn_close.addConstraints([ heightConstraintClose, withConstraintClose])
            
            let horizontalConstraintStar1 = NSLayoutConstraint(item: imageStar1 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.67, constant: 0)
            view.addConstraint(horizontalConstraintStar1)
            let verticalConstraintStar3 = NSLayoutConstraint(item: imageStar3 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.33, constant: 0)
            view.addConstraint(verticalConstraintStar3)
            
            let heightConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            btn_Menu.addConstraints([ heightConstraintMenu, withConstraintMenu])
            
            labelText.font = UIFont(name: "Chalkboard SE Bold", size: 25)
            labelScore.font = UIFont(name: "Arial Bold", size: 40)
        }
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(ImageBack))
        imageback.addGestureRecognizer(tapGR)
        imageback.isUserInteractionEnabled = true
    }
    @objc func ImageBack(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true, completion: nil)
        
    }
    @IBAction func Btn_Menu(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: MenuViewController = storyboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
}
