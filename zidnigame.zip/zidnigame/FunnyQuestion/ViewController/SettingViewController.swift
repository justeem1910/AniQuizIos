//
//  SettingViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 21/07/2021.
//

import UIKit


class SettingViewController: UIViewController {
    @IBOutlet weak var imageBack:UIImageView!
    @IBOutlet weak var labelSetting:UILabel!
    @IBOutlet weak var labelAchieve:UILabel!
    @IBOutlet weak var labelSound:UILabel!
    @IBOutlet weak var labelMusic:UILabel!
    @IBOutlet weak var labelInstructionn:UILabel!
    
    @IBOutlet weak var viewAchieve:UIView!
    @IBOutlet weak var viewSound:UIView!
    @IBOutlet weak var viewMusic:UIView!
    @IBOutlet weak var viewInstruction:UIView!
    
    @IBOutlet weak var switchSound:UISwitch!
    @IBOutlet weak var switchMusic:UISwitch!
    var application:UIApplication!
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var music: Int = UserDefaults.standard.integer(forKey: "Music")
    var sound: Int = UserDefaults.standard.integer(forKey: "Sound")

    override func viewWillAppear(_ animated: Bool) {
        if  UserDefaults.standard.integer(forKey: "Sound") == 0 {
            UserDefaults.standard.setValue(1, forKey: "Sound")
        }
        if  UserDefaults.standard.integer(forKey: "Music") == 0 {
            UserDefaults.standard.setValue(1, forKey: "Music")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1 la mo nhac, 2 la tat nhac
        if sound == 1 {
            switchSound.setOn(true, animated: true)
        }
        if sound == 2 {
            switchSound.setOn(false, animated: true)
        }
        
        // 1 la mo nhac, 2 la tat nhac
        if music == 1 {
            switchMusic.setOn(true, animated: true)
        }
        if music == 2 {
            switchMusic.setOn(false, animated: false)
        }
        
        if UIDevice.current.userInterfaceIdiom == .pad{
            let heightConstraintBack = NSLayoutConstraint(item: imageBack as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            let withConstraintBack = NSLayoutConstraint(item: imageBack as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            imageBack.addConstraints([ heightConstraintBack, withConstraintBack])
            
            labelSetting.font = UIFont(name: "Chalkboard SE Bold", size: 50)
            labelMusic.font = UIFont(name: "Chalkboard SE Bold", size: 35)
            labelSound.font = UIFont(name: "Chalkboard SE Bold", size: 35)
            labelAchieve.font = UIFont(name: "Chalkboard SE Bold", size: 35)
            labelInstructionn.font = UIFont(name: "Chalkboard SE Bold", size: 35)
        }else{
            let heightConstraintBack = NSLayoutConstraint(item: imageBack as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: imageBack as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageBack.addConstraints([ heightConstraintBack, withConstraintBack])
            
            labelSetting.font = UIFont(name: "Chalkboard SE Bold", size: 30)
            labelMusic.font = UIFont(name: "Chalkboard SE Bold", size: 23)
            labelSound.font = UIFont(name: "Chalkboard SE Bold", size: 23)
            labelAchieve.font = UIFont(name: "Chalkboard SE Bold", size: 23)
            labelInstructionn.font = UIFont(name: "Chalkboard SE Bold", size: 23)
        }
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(ImageBack))
        imageBack.addGestureRecognizer(tapGR)
        imageBack.isUserInteractionEnabled = true
        
        let tapGR1 = UITapGestureRecognizer(target: self, action: #selector(ViewInstruction))
        viewInstruction.addGestureRecognizer(tapGR1)
        viewInstruction.isUserInteractionEnabled = true
        
        let tapGR2 = UITapGestureRecognizer(target: self, action: #selector(ViewAchieve))
        viewAchieve.addGestureRecognizer(tapGR2)
        viewAchieve.isUserInteractionEnabled = true
        
        let tapGR3 = UITapGestureRecognizer(target: self, action: #selector(ViewMusic))
        viewMusic.addGestureRecognizer(tapGR3)
        viewMusic.isUserInteractionEnabled = true
        
        let tapGR4 = UITapGestureRecognizer(target: self, action: #selector(ViewSound))
        viewSound.addGestureRecognizer(tapGR4)
        viewSound.isUserInteractionEnabled = true
    }
    @objc func ImageBack(tapGR: UITapGestureRecognizer){
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true, completion: nil)
    }
    @objc func ViewInstruction(tapGR: UITapGestureRecognizer){
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: InstructionViewController = storyboard.instantiateViewController(withIdentifier: "InstructionViewController") as! InstructionViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func ViewAchieve(tapGR: UITapGestureRecognizer){
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: AchieveViewController = storyboard.instantiateViewController(withIdentifier: "AchieveViewController") as! AchieveViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func ViewMusic(tapGR: UITapGestureRecognizer){
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        
        // 1 la mo nhac, 2 la tat nhac
        if music == 1 {
            music = 2
            UserDefaults.standard.setValue(music, forKey: "Music")
            switchMusic.setOn(false, animated: true)
            musicPlayer.stopBackgroundMusic()
        }else if music == 2 {
            music = 1
            UserDefaults.standard.setValue(music, forKey: "Music")
            switchMusic.setOn(true, animated: true)
            if sound == 1 {
                musicPlayer.startBackgroundMusic()
            } else if sound == 2 {
                musicPlayer.stopBackgroundMusic()
                
            }
            
        }
    }
    @objc func ViewSound(tapGR: UITapGestureRecognizer){
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        // 1 la mo nhac, 2 la tat nhac
        if sound == 1 {
            sound = 2
            UserDefaults.standard.setValue(sound, forKey: "Sound")
            switchSound.setOn(false, animated: true)
            musicPlayer.stopBackgroundMusic()
            musicPlayer.stopEffectMusic()
        }else if sound == 2 {
            sound = 1
            UserDefaults.standard.setValue(sound, forKey: "Sound")
            switchSound.setOn(true, animated: true)
            if  music == 1{
                musicPlayer.startBackgroundMusic()
            } else if music == 2 {
                musicPlayer.stopBackgroundMusic()
            }
        }
    }
    
    @IBAction func SwitchSound(_ sender: Any) {
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if switchSound.isOn == false{
            sound = 2
            UserDefaults.standard.setValue(sound, forKey: "Sound")
            switchSound.setOn(false, animated: true)
            musicPlayer.stopBackgroundMusic()
            musicPlayer.stopEffectMusic()
        }else if switchSound.isOn == true {
            sound = 1
            UserDefaults.standard.setValue(sound, forKey: "Sound")
            switchSound.setOn(true, animated: true)
            if  music == 1{
                musicPlayer.startBackgroundMusic()
            } else if music == 2 {
                musicPlayer.stopBackgroundMusic()
            }
        }
    }
    
    @IBAction func SwitchMusicCheck(_ sender: Any) {
        if sound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if switchMusic.isOn == false {
            music = 2
            UserDefaults.standard.setValue(music, forKey: "Music")
            switchMusic.setOn(false, animated: true)
            musicPlayer.stopBackgroundMusic()
        }else if switchMusic.isOn == true {
            music = 1
            UserDefaults.standard.setValue(music, forKey: "Music")
            switchMusic.setOn(true, animated: true)
            if sound == 1 {
                musicPlayer.startBackgroundMusic()
            } else if sound == 2 {
                musicPlayer.stopBackgroundMusic()
                
            }
            
        }
    }
}
