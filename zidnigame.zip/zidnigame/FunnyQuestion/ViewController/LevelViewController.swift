//
//  LevelViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 24/06/2021.
//

import UIKit
extension NSObject {
    func background(delay: Double = 0.0, background: (()->Void)? = nil, completion: (() -> Void)? = nil) {
        DispatchQueue.global(qos: .background).async {
            background?()
            if let completion = completion {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: {
                    completion()
                })
            }
        }
    }
    var className: String {
        return String(describing: type(of: self))
    }
    class var className: String {
        return String(describing: self)
    }
}
class LevelViewController: UIViewController {
    @IBOutlet weak var collectionViewMain:UICollectionView!
    @IBOutlet weak var imageback:UIImageView!
    @IBOutlet weak var imageSetting:UIImageView!
    @IBOutlet weak var labelLevel:UILabel!
    @IBOutlet weak var imageIcon2:UIImageView!
    
    var indexSelected = 0
    
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if UIDevice.current.userInterfaceIdiom == .pad{
            labelLevel.font = UIFont(name: "Chalkboard SE Bold", size: 50)
            
            let heightConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            let withConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            imageback.addConstraints([ heightConstraintBack, withConstraintBack])
            

            
            let heightConstraintSetting = NSLayoutConstraint(item: imageSetting as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            let withConstraintSetting = NSLayoutConstraint(item: imageSetting as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            imageSetting.addConstraints([ heightConstraintSetting, withConstraintSetting])
            
            
            let horizontalConstraintIcon1 = NSLayoutConstraint(item: imageIcon2 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.5, constant: 0)
            view.addConstraint(horizontalConstraintIcon1)
            let verticalConstraintIcon1 = NSLayoutConstraint(item: imageIcon2 as Any, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.98, constant: 0)
                
            view.addConstraint(verticalConstraintIcon1)
            
            
            
        } else{
            labelLevel.font = UIFont(name: "Chalkboard SE Bold", size: 30)
            
            let heightConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: imageback as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageback.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintSetting = NSLayoutConstraint(item: imageSetting as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintSetting = NSLayoutConstraint(item: imageSetting as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageSetting.addConstraints([ heightConstraintSetting, withConstraintSetting])
            
            let horizontalConstraintIcon1 = NSLayoutConstraint(item: imageIcon2 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.1, constant: 0)
            view.addConstraint(horizontalConstraintIcon1)
            let verticalConstraintIcon1 = NSLayoutConstraint(item: imageIcon2 as Any, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.9, constant: 0)
                
            view.addConstraint(verticalConstraintIcon1)
        }
        
        
        
        collectionViewMain.register(UINib(nibName: ItemLevelCVLCell.className, bundle: nil), forCellWithReuseIdentifier: ItemLevelCVLCell.className)
        collectionViewMain.backgroundColor = UIColor.clear
        collectionViewMain.showsVerticalScrollIndicator = false
        collectionViewMain.showsHorizontalScrollIndicator = false
        //ItemLevelCVLCell
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(ImageBack))
        imageback.addGestureRecognizer(tapGR)
        imageback.isUserInteractionEnabled = true
        
        let tapGR1 = UITapGestureRecognizer(target: self, action: #selector(ImageSetting))
        imageSetting.addGestureRecognizer(tapGR1)
        imageSetting.isUserInteractionEnabled = true
        
    }
    @objc func ImageBack(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true, completion: nil)
        
    }
    @objc func ImageSetting(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: SettingViewController = storyboard.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
}
extension LevelViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 25
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ItemLevelCVLCell.className, for: indexPath) as! ItemLevelCVLCell
        cell.labelName.text = String(indexPath.row+1  )
        if indexPath.row == 0 || indexPath.row == 10 || indexPath.row==20{
            cell.imageBackground.image = UIImage.init(named: "level1")
        }
        if indexPath.row == 1 || indexPath.row == 11 || indexPath.row==21{
            cell.imageBackground.image = UIImage.init(named: "level2")
        }
        if indexPath.row == 2 || indexPath.row == 12 || indexPath.row==22{
            cell.imageBackground.image = UIImage.init(named: "level3")
        }
        if indexPath.row == 3 || indexPath.row == 13 || indexPath.row==23{
            cell.imageBackground.image = UIImage.init(named: "level4")
        }
        if indexPath.row == 4 || indexPath.row == 14 || indexPath.row==24{
            cell.imageBackground.image = UIImage.init(named: "level5")
        }
        if indexPath.row == 5 || indexPath.row == 15 {
            cell.imageBackground.image = UIImage.init(named: "level6")
        }
        if indexPath.row == 6 || indexPath.row == 16 {
            cell.imageBackground.image = UIImage.init(named: "level7")
        }
        if indexPath.row == 7 || indexPath.row == 17 {
            cell.imageBackground.image = UIImage.init(named: "level8")
        }
        if indexPath.row == 8 || indexPath.row == 18 {
            cell.imageBackground.image = UIImage.init(named: "level9")
        }
        if indexPath.row == 9 || indexPath.row == 19 {
            cell.imageBackground.image = UIImage.init(named: "level10")
        }
        if UIDevice.current.userInterfaceIdiom == .pad {
            cell.labelName.font = UIFont.boldSystemFont(ofSize: 30.0)
        } else{
            cell.labelName.font = UIFont.boldSystemFont(ofSize: 15)
        }
    
        return cell
    }
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        return UICollectionReusableView()
    }
    
}

extension LevelViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 25
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if UIDevice.current.userInterfaceIdiom == .pad{
            return (collectionView.frame.width)*0.02
        }else{
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if UIDevice.current.userInterfaceIdiom == .pad{
            let with = (collectionView.frame.width)*0.16
            let heigh = with
            return CGSize(width: with, height: heigh)
        }else{
            let with = (collectionView.frame.width)*0.185
            let heigh = with
            return CGSize(width: with,height: heigh)
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: QuestionViewController = storyboard.instantiateViewController(withIdentifier: "QuestionViewController") as! QuestionViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        vc.levelQuestion = indexPath.row + 1
        self.present(vc, animated: true, completion: nil)
    
    }

}
