//
//  PopUpViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 16/07/2021.
//

import UIKit

class PopUpViewController: UIViewController {
    
    @IBOutlet weak var labelTitle:UILabel!
    @IBOutlet weak var labelMessage:UILabel!
    @IBOutlet weak var btn_ok:UIButton!
    @IBOutlet weak var viewPop:UIView!
    
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelTitle.text = "Message"
        labelMessage.text = "You don't have enough money to use this help"
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            
            viewPop.layer.cornerRadius = 40
            viewPop.layer.masksToBounds = true
            
            labelTitle.font = UIFont.boldSystemFont(ofSize: 33)
            labelMessage.font = UIFont.systemFont(ofSize: 30)
            btn_ok.titleLabel?.font = UIFont.boldSystemFont(ofSize: 33)
            
        }
        else{
            viewPop.layer.cornerRadius = 20
            viewPop.layer.masksToBounds = true
            
            labelTitle.font = UIFont.boldSystemFont(ofSize: 25)
            labelMessage.font = UIFont.systemFont(ofSize: 20)
            btn_ok.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
                if touch?.view != self.viewPop{
                    if checkSound == 1{
                        musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
                    }
                    self.dismiss(animated: true, completion: nil)
                }
    }
    
    @IBAction func btn_Ok(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true)
    }
    
}
