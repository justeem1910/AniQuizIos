//
//  ScoreViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 17/07/2021.
//

import UIKit

class ScoreViewController: UIViewController {
    
    @IBOutlet weak var btn_close:UIButton!
    @IBOutlet weak var imageBackground:UIImageView!
    @IBOutlet weak var imageStar1:UIImageView!
    @IBOutlet weak var imageStar2:UIImageView!
    @IBOutlet weak var imageStar3:UIImageView!
    @IBOutlet weak var imageMoney:UIImageView!
    @IBOutlet weak var imagePs:UIImageView!
    
    @IBOutlet weak var labelText:UILabel!
    @IBOutlet weak var labelScore:UILabel!
    @IBOutlet weak var labelMoney:UILabel!
    @IBOutlet weak var labelPs:UILabel!
//    @IBOutlet weak var labelHighScore:UILabel!
    @IBOutlet weak var btn_Back:UIButton!
    @IBOutlet weak var btn_Look:UIButton!
    @IBOutlet weak var btn_Menu:UIButton!
    @IBOutlet weak var btn_Share:UIButton!
    
    @IBOutlet weak var view_Money:UIView!
    @IBOutlet weak var view_Ps:UIView!
    
    
    var hintCorrect: Int = 0
    var hintMoney:Int = 0
    var hintLevelQuestion:Int = 0
    var questionScoreArray:[QuestionModel] = [QuestionModel]()
    var listCorrectHint:[String] = [String]()
    var listIncorrectHint:[String] = [String]()
    
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        labelHighScore.isHidden = true
        labelScore.text = "\(hintCorrect)/10"
        labelPs.text = String(hintCorrect*5 - (10-hintCorrect)*2)
        if  hintCorrect < 5 {
            labelText.text = "Not good!"
            labelMoney.text = "0"
            imageStar2.isHidden = false
            
        } else if hintCorrect < 8 && hintCorrect > 4 {
            labelText.text = "good job!"
            imageStar1.isHidden = false
            imageStar2.isHidden = false
            
            hintMoney = UserDefaults.standard.integer(forKey: "Money")
            hintMoney += 1
            labelMoney.text = "1"
            UserDefaults.standard.setValue(hintMoney, forKey: "Money")
        } else {
            labelText.text = "very excellent!"
            imageStar1.isHidden = false
            imageStar2.isHidden = false
            imageStar3.isHidden = false
            if hintCorrect >= 8 && hintCorrect < 10 {
                labelMoney.text = "3"
                hintMoney = UserDefaults.standard.integer(forKey: "Money")
                hintMoney += 3
                UserDefaults.standard.setValue(hintMoney, forKey: "Money")
            }else if hintCorrect == 10 {
                labelMoney.text = "5"
                hintMoney = UserDefaults.standard.integer(forKey: "Money")
                hintMoney += 5
                UserDefaults.standard.setValue(hintMoney, forKey: "Money")
            }
        }
        
        if UIDevice.current.userInterfaceIdiom == .pad{
            let heightConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_close.addConstraints([ heightConstraintClose, withConstraintClose])
            
            let horizontalConstraintStar1 = NSLayoutConstraint(item: imageStar1 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.75, constant: 0)
            view.addConstraint(horizontalConstraintStar1)
            let verticalConstraintStar3 = NSLayoutConstraint(item: imageStar3 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.25, constant: 0)
            view.addConstraint(verticalConstraintStar3)
            
            let heightConstraintBack = NSLayoutConstraint(item: btn_Back as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintBack = NSLayoutConstraint(item: btn_Back as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_Back.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintLook = NSLayoutConstraint(item: btn_Look as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintLook = NSLayoutConstraint(item: btn_Look as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_Look.addConstraints([ heightConstraintLook, withConstraintLook])
            
            let heightConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_Menu.addConstraints([ heightConstraintMenu, withConstraintMenu])
            
            let heightConstraintShare = NSLayoutConstraint(item: btn_Share as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintShare = NSLayoutConstraint(item: btn_Share as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            btn_Share.addConstraints([ heightConstraintShare, withConstraintShare])
            
            let horizontalConstraintMoney = NSLayoutConstraint(item: imageMoney as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Money, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0)
            view.addConstraint(horizontalConstraintMoney)
            
            let horizontalConstraintMoneyLabel = NSLayoutConstraint(item: labelMoney as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Money, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.8, constant: 0)
            view.addConstraint(horizontalConstraintMoneyLabel)
            
            let horizontalConstraintPs = NSLayoutConstraint(item: imagePs as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Ps, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.05, constant: 0)
            view.addConstraint(horizontalConstraintPs)
            
            let horizontalConstraintPsLabel = NSLayoutConstraint(item: labelPs as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Ps, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.9, constant: 0)
            view.addConstraint(horizontalConstraintPsLabel)
            
            
            labelText.font = UIFont(name: "Chalkboard SE Bold", size: 50)
            labelScore.font = UIFont(name: "Arial Bold", size: 120)
            labelMoney.font = UIFont(name: "Arial Bold", size: 35)
            labelPs.font = UIFont(name: "Arial Bold", size: 35)
//            labelHighScore.font = UIFont.systemFont(ofSize: 35)
            
            
            
        } else{
            let heightConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintClose = NSLayoutConstraint(item: btn_close as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            btn_close.addConstraints([ heightConstraintClose, withConstraintClose])
            
            let horizontalConstraintStar1 = NSLayoutConstraint(item: imageStar1 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.67, constant: 0)
            view.addConstraint(horizontalConstraintStar1)
            let verticalConstraintStar3 = NSLayoutConstraint(item: imageStar3 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: imageBackground, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.33, constant: 0)
            view.addConstraint(verticalConstraintStar3)
            
            let heightConstraintBack = NSLayoutConstraint(item: btn_Back as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: btn_Back as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            btn_Back.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintLook = NSLayoutConstraint(item: btn_Look as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintLook = NSLayoutConstraint(item: btn_Look as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            btn_Look.addConstraints([ heightConstraintLook, withConstraintLook])
            
            let heightConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintMenu = NSLayoutConstraint(item: btn_Menu as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            btn_Menu.addConstraints([ heightConstraintMenu, withConstraintMenu])
            
            let heightConstraintShare = NSLayoutConstraint(item: btn_Share as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintShare = NSLayoutConstraint(item: btn_Share as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            btn_Share.addConstraints([ heightConstraintShare, withConstraintShare])
            
            
            
            let horizontalConstraintMoney = NSLayoutConstraint(item: imageMoney as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Money, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1, constant: 0)
            view.addConstraint(horizontalConstraintMoney)
            
            let horizontalConstraintMoneyLabel = NSLayoutConstraint(item: labelMoney as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Money, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.75, constant: 0)
            view.addConstraint(horizontalConstraintMoneyLabel)
            
            let horizontalConstraintPs = NSLayoutConstraint(item: imagePs as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Ps, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.1, constant: 0)
            view.addConstraint(horizontalConstraintPs)
            
            let horizontalConstraintPsLabel = NSLayoutConstraint(item: labelPs as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view_Ps, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 0.95, constant: 0)
            view.addConstraint(horizontalConstraintPsLabel)
            
            labelText.font = UIFont(name: "Chalkboard SE Bold", size: 25)
            labelScore.font = UIFont(name: "Arial Bold", size: 80)
            labelMoney.font = UIFont(name: "Arial Bold", size: 20)
            labelPs.font = UIFont(name: "Arial Bold", size: 20)
            
//            labelHighScore.font = UIFont.systemFont(ofSize: 22)
        }
    }

    @IBAction func Btn_Back(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: LevelViewController = storyboard.instantiateViewController(withIdentifier: "LevelViewController") as! LevelViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func Btn_look(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: HintQuestionViewController = storyboard.instantiateViewController(withIdentifier: "HintQuestionViewController") as! HintQuestionViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        vc.levelQuestionHint = hintLevelQuestion
        vc.CorrectArray = listCorrectHint
        vc.InCorrectArray = listIncorrectHint
        vc.QuestionHintArray = questionScoreArray
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func Btn_menu(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: MenuViewController = storyboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
}
