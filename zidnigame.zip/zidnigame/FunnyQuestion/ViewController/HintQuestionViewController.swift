//
//  HintQuestionViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 18/07/2021.
//

import UIKit

class HintQuestionViewController: UIViewController {
    
    @IBOutlet weak var viewOptionA:UIView!
    @IBOutlet weak var viewOptionB:UIView!
    @IBOutlet weak var viewOptionC:UIView!
    @IBOutlet weak var viewOptionD:UIView!
    
    @IBOutlet weak var labelNumQues:UILabel!
    @IBOutlet weak var labelQuestion:UILabel!
    @IBOutlet weak var labelOptionA:UILabel!
    @IBOutlet weak var labelOptionB:UILabel!
    @IBOutlet weak var labelOptionC:UILabel!
    @IBOutlet weak var labelOptionD:UILabel!
    @IBOutlet weak var labelNumberQuestionb:UILabel!
    
    @IBOutlet weak var btn_a:UIButton!
    @IBOutlet weak var btn_b:UIButton!
    @IBOutlet weak var btn_c:UIButton!
    @IBOutlet weak var btn_d:UIButton!
    
    @IBOutlet weak var imageBack3:UIImageView!
    @IBOutlet weak var imageSetting3:UIImageView!
    @IBOutlet weak var imageBackHint:UIImageView!
    @IBOutlet weak var imageNextHint:UIImageView!
    
    var levelQuestionHint:Int = 0
    var QuestionHintArray:[QuestionModel] = [QuestionModel]()
    var InCorrectArray:[String] = [String]()
    var CorrectArray:[String] = [String]()
    
    var i:Int = 0
    
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelNumQues.text = "Level \(levelQuestionHint)"
        labelNumberQuestionb.text = "\(i+1)/10"
        
        viewOptionA.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        viewOptionB.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        viewOptionC.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        viewOptionD.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            labelNumQues.font = UIFont.boldSystemFont(ofSize: 38)
            labelNumberQuestionb.font = UIFont.boldSystemFont(ofSize: 33)
            labelQuestion.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionA.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionB.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionC.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionD.font = UIFont.boldSystemFont(ofSize: 33)
            
            viewOptionA.layer.cornerRadius = 20
            viewOptionB.layer.cornerRadius = 20
            viewOptionC.layer.cornerRadius = 20
            viewOptionD.layer.cornerRadius = 20
            
            btn_a.layer.cornerRadius = 15
            btn_b.layer.cornerRadius = 15
            btn_c.layer.cornerRadius = 15
            btn_d.layer.cornerRadius = 15
            
            let heightConstraintBackHint = NSLayoutConstraint(item: imageBackHint as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            let widthConstraintBackHint = NSLayoutConstraint(item: imageBackHint as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            imageBackHint.addConstraints([ widthConstraintBackHint, heightConstraintBackHint])
            
            let heightConstraintNextHint = NSLayoutConstraint(item: imageNextHint as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            let widthConstraintNextHint = NSLayoutConstraint(item: imageNextHint as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            imageNextHint.addConstraints([ widthConstraintNextHint, heightConstraintNextHint])
            
            
            let heightConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 90)
            let withConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            imageBack3.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 90)
            let withConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            imageSetting3.addConstraints([ heightConstraintSetting, withConstraintSetting])
        }else{
            labelNumQues.font = UIFont.boldSystemFont(ofSize: 30)
            labelNumberQuestionb.font = UIFont.boldSystemFont(ofSize: 20)
            labelQuestion.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionA.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionB.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionC.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionD.font = UIFont.boldSystemFont(ofSize: 20)
            
            viewOptionA.layer.cornerRadius = 15
            viewOptionB.layer.cornerRadius = 15
            viewOptionC.layer.cornerRadius = 15
            viewOptionD.layer.cornerRadius = 15
            
            btn_a.layer.cornerRadius = 10
            btn_b.layer.cornerRadius = 10
            btn_c.layer.cornerRadius = 10
            btn_d.layer.cornerRadius = 10
            
            let heightConstraintBackHint = NSLayoutConstraint(item: imageBackHint as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 60)
            let widthConstraintBackHint = NSLayoutConstraint(item: imageBackHint as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 60)
            imageBackHint.addConstraints([ widthConstraintBackHint, heightConstraintBackHint])
            
            let heightConstraintNextHint = NSLayoutConstraint(item: imageNextHint as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 60)
            let widthConstraintNextHint = NSLayoutConstraint(item: imageNextHint as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 60)
            imageNextHint.addConstraints([ widthConstraintNextHint, heightConstraintNextHint])
            
            let heightConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageBack3.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageSetting3.addConstraints([ heightConstraintSetting, withConstraintSetting])
            
        }
        
        let questionModel:QuestionModel = QuestionHintArray[i]
//        print("aaaaa \(questionModel.question)")
        labelQuestion.text = String(questionModel.question)
        labelOptionA.text = String(questionModel.option_a)
        labelOptionB.text = String(questionModel.option_b)
        labelOptionC.text = String(questionModel.option_c)
        labelOptionD.text = String(questionModel.option_d)
        
        if questionModel.option_a == CorrectArray[i] {
            viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
        } else if questionModel.option_b == CorrectArray[i] {
            viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
        } else if questionModel.option_c == CorrectArray[i] {
            viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
        } else if questionModel.option_d == CorrectArray[i] {
            viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
        }
        
        if InCorrectArray[i] == "1" {
            viewOptionA.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
        } else if InCorrectArray[i] == "2" {
            viewOptionB.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
        } else if InCorrectArray[i] == "3" {
            viewOptionC.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
        } else if InCorrectArray[i] == "4" {
            viewOptionD.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
        }
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(ImageBack))
        imageBack3.addGestureRecognizer(tapGR)
        imageBack3.isUserInteractionEnabled = true
        
        let tapGR1 = UITapGestureRecognizer(target: self, action: #selector(ImageNextHint))
        imageNextHint.addGestureRecognizer(tapGR1)
        imageNextHint.isUserInteractionEnabled = true
        
        let tapGR2 = UITapGestureRecognizer(target: self, action: #selector(ImageBackHint))
        imageBackHint.addGestureRecognizer(tapGR2)
        imageBackHint.isUserInteractionEnabled = true
        
        let tapGR3 = UITapGestureRecognizer(target: self, action: #selector(ImageSetting))
        imageSetting3.addGestureRecognizer(tapGR3)
        imageSetting3.isUserInteractionEnabled = true
        
    }
    @objc func ImageBack(tapGR:UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true, completion: nil)
    }
    
    @objc func ImageBackHint(tapGR:UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if i > 0 {
            i-=1
            viewDidLoad()
        }
    }
    
    @objc func ImageNextHint(tapGR:UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if i < 9 {
            i+=1
            viewDidLoad()
        }
    }
    
    @objc func ImageSetting(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: SettingViewController = storyboard.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
    

}
