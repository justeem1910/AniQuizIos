//
//  MainViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 08/07/2021.
//

import UIKit

class MainViewController: UIViewController {
    @IBOutlet weak var labeTitle:UILabel!
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    
    var music: Int = 0
    var sound: Int = 0
    
    override func viewWillAppear(_ animated: Bool) {
        if  UserDefaults.standard.integer(forKey: "Sound") == 0 {
            UserDefaults.standard.setValue(1, forKey: "Sound")
        }
        if  UserDefaults.standard.integer(forKey: "Music") == 0 {
            UserDefaults.standard.setValue(1, forKey: "Music")
        }
        sound = UserDefaults.standard.integer(forKey: "Sound")
        music = UserDefaults.standard.integer(forKey: "Music")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var itemSecond = 0
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if itemSecond == 1 {
                if self.sound == 1 && self.music == 1 {
                    self.musicPlayer.startBackgroundMusic()
                }
                let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let vc:MenuViewController = storyboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true, completion: nil)
                timer.invalidate()
            }
            itemSecond = itemSecond + 1
        }
        
    }
}
