//
//  MenuViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 24/06/2021.
//

import UIKit

class MenuViewController: UIViewController {
    @IBOutlet weak var imageClock:UIImageView!
    @IBOutlet weak var imageCup:UIImageView!
    @IBOutlet weak var imageSetting:UIImageView!
    @IBOutlet weak var imageRank:UIImageView!
    @IBOutlet weak var btn_exercise:UIImageView!
    @IBOutlet weak var btn_setting:UIImageView!
    @IBOutlet weak var btn_achieve:UIImageView!
    @IBOutlet weak var imageIcon1:UIImageView!
    @IBOutlet weak var labelClock:UILabel!
    @IBOutlet weak var labelCup:UILabel!
    @IBOutlet weak var labelRank:UILabel!
    @IBOutlet weak var labelSetting:UILabel!

    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        if UIDevice.current.userInterfaceIdiom == .pad {
            let horizontalConstraintClock = NSLayoutConstraint(item: imageClock as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.3, constant: 0)
                view.addConstraint(horizontalConstraintClock)
            let horizontalConstraintCup = NSLayoutConstraint(item: imageCup as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.3, constant: 0)
                view.addConstraint(horizontalConstraintCup)
            let horizontalConstraintSetting = NSLayoutConstraint(item: imageSetting as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.3, constant: 0)
                view.addConstraint(horizontalConstraintSetting)
            let horizontalConstraintRank = NSLayoutConstraint(item: imageRank as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.3, constant: 0)
                view.addConstraint(horizontalConstraintRank)
            
            labelClock.font = UIFont(name: "Chalkboard SE Bold", size: 42)
            labelCup.font = UIFont(name: "Chalkboard SE Bold", size: 42)
            labelRank.font = UIFont(name: "Chalkboard SE Bold", size: 42)
            labelSetting.font = UIFont(name: "Chalkboard SE Bold", size: 42)
            
            let horizontalConstraintIcon1 = NSLayoutConstraint(item: imageIcon1 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.5, constant: 0)
            view.addConstraint(horizontalConstraintIcon1)
            let verticalConstraintIcon1 = NSLayoutConstraint(item: imageIcon1 as Any, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.98, constant: 0)
            view.addConstraint(verticalConstraintIcon1)
            
         } else {
            let horizontalConstraintClock = NSLayoutConstraint(item: imageClock as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.5, constant: 0)
                view.addConstraint(horizontalConstraintClock)
            let horizontalConstraintCup = NSLayoutConstraint(item: imageCup as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.5, constant: 0)
                view.addConstraint(horizontalConstraintCup)
            let horizontalConstraintSetting = NSLayoutConstraint(item: imageSetting as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.5, constant: 0)
                view.addConstraint(horizontalConstraintSetting)
            let horizontalConstraintRank = NSLayoutConstraint(item: imageRank as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.5, constant: 0)
                view.addConstraint(horizontalConstraintRank)
            
            let horizontalConstraintIcon1 = NSLayoutConstraint(item: imageIcon1 as Any, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.1, constant: 0)
            view.addConstraint(horizontalConstraintIcon1)
            let verticalConstraintIcon1 = NSLayoutConstraint(item: imageIcon1 as Any, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.95, constant: 0)
                
            view.addConstraint(verticalConstraintIcon1)
            
            labelClock.font = UIFont(name: "Chalkboard SE Bold", size: 32)
            labelCup.font = UIFont(name: "Chalkboard SE Bold", size: 32)
            labelRank.font = UIFont(name: "Chalkboard SE Bold", size: 32)
            labelSetting.font = UIFont(name: "Chalkboard SE Bold", size: 32)
        
        }
        
    
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(self.BtnExercise))
            btn_exercise.addGestureRecognizer(tapGR)
            btn_exercise.isUserInteractionEnabled = true
        
        let tapGR1 = UITapGestureRecognizer(target: self, action: #selector(self.BtnSetting))
            btn_setting.addGestureRecognizer(tapGR1)
            btn_setting.isUserInteractionEnabled = true
        
        let tapGR2 = UITapGestureRecognizer(target: self, action: #selector(BtnAchieve))
        btn_achieve.addGestureRecognizer(tapGR2)
        btn_achieve.isUserInteractionEnabled = true
    }
    
    @objc func BtnExercise(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: UIViewController = storyboard.instantiateViewController(withIdentifier: "LevelViewController") as! LevelViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func BtnSetting(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: SettingViewController = storyboard.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func BtnAchieve(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: AchieveViewController = storyboard.instantiateViewController(withIdentifier: "AchieveViewController") as! AchieveViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    
}
