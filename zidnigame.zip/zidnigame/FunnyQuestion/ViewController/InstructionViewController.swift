//
//  InstructionViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 22/07/2021.
//

import UIKit

class InstructionViewController: UIViewController {
    
    @IBOutlet weak var image_back:UIImageView!
    @IBOutlet weak var labelInstruction:UILabel!
    @IBOutlet weak var labelCorrect:UILabel!
    @IBOutlet weak var labelIncorrect:UILabel!
    @IBOutlet weak var labelMoney:UILabel!
    @IBOutlet weak var labelPS:UILabel!
    @IBOutlet weak var labelHelp:UILabel!
    @IBOutlet weak var label5050:UILabel!
    @IBOutlet weak var labelNext:UILabel!
    @IBOutlet weak var labelClock:UILabel!
    
    @IBOutlet weak var viewInstruction:UIView!
    @IBOutlet weak var viewHelp:UIView!
    
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkSound:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UIDevice.current.userInterfaceIdiom == .pad{
            let heightConstraintBack = NSLayoutConstraint(item: image_back as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            let withConstraintBack = NSLayoutConstraint(item: image_back as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 80)
            image_back.addConstraints([ heightConstraintBack, withConstraintBack])
            
            
            labelInstruction.font = UIFont(name: "Chalkboard SE Bold", size: 50)
            labelCorrect.font = UIFont.boldSystemFont(ofSize: 33)
            labelIncorrect.font = UIFont.boldSystemFont(ofSize: 33)
            labelPS.font = UIFont.boldSystemFont(ofSize: 33)
            labelMoney.font = UIFont.boldSystemFont(ofSize: 33)
            labelHelp.font = UIFont.boldSystemFont(ofSize: 33)
            label5050.font = UIFont.boldSystemFont(ofSize: 33)
            labelNext.font = UIFont.boldSystemFont(ofSize: 33)
            labelClock.font = UIFont.boldSystemFont(ofSize: 33)
            
            viewInstruction.layer.cornerRadius = 30
            viewHelp.layer.cornerRadius = 30
            
        } else{
            let heightConstraintBack = NSLayoutConstraint(item: image_back as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: image_back as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 0, constant: 50)
            image_back.addConstraints([ heightConstraintBack, withConstraintBack])
            
            
            labelInstruction.font = UIFont(name: "Chalkboard SE Bold", size: 30)
            labelCorrect.font = UIFont.boldSystemFont(ofSize: 19)
            labelIncorrect.font = UIFont.boldSystemFont(ofSize: 19)
            labelPS.font = UIFont.boldSystemFont(ofSize: 19)
            labelMoney.font = UIFont.boldSystemFont(ofSize: 19)
            labelHelp.font = UIFont.boldSystemFont(ofSize: 19)
            label5050.font = UIFont.boldSystemFont(ofSize: 19)
            labelNext.font = UIFont.boldSystemFont(ofSize: 19)
            labelClock.font = UIFont.boldSystemFont(ofSize: 19)
            
            viewInstruction.layer.cornerRadius = 15
            viewHelp.layer.cornerRadius = 15
        }
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(ImageBack))
        image_back.addGestureRecognizer(tapGR)
        image_back.isUserInteractionEnabled = true
    }
    @objc func ImageBack(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true, completion: nil)
    }
    
}
