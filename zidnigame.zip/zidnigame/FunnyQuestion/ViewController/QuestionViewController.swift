//
//  QuestionViewController.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 30/06/2021.
//

import UIKit
import  CircleProgressBar

class QuestionViewController: UIViewController {
    
    @IBOutlet weak var labelQuestion:UILabel!
    @IBOutlet weak var labelOptionA:UILabel!
    @IBOutlet weak var labelOptionB:UILabel!
    @IBOutlet weak var labelOptionC:UILabel!
    @IBOutlet weak var labelOptionD:UILabel!
    @IBOutlet weak var viewOptionA:UIView!
    @IBOutlet weak var viewOptionB:UIView!
    @IBOutlet weak var viewOptionC:UIView!
    @IBOutlet weak var viewOptionD:UIView!
    @IBOutlet weak var labelNumQues:UILabel!
    @IBOutlet weak var btn_a:UIButton!
    @IBOutlet weak var btn_b:UIButton!
    @IBOutlet weak var btn_c:UIButton!
    @IBOutlet weak var btn_d:UIButton!
    @IBOutlet weak var labelCorrect:UILabel!
    @IBOutlet weak var labelINCorrect:UILabel!
    @IBOutlet weak var labelMoney:UILabel!
    @IBOutlet weak var labelPs:UILabel!
    @IBOutlet weak var labelNumerQuestion:UILabel!
    @IBOutlet weak var imageBack3: UIImageView!
    @IBOutlet weak var imageSetting3:UIImageView!
    
    @IBOutlet weak var timeCircle:CircleProgressBar!
    
    @IBOutlet weak var labelcheckTime:UILabel!
    @IBOutlet weak var btn_clock:UIButton!
    @IBOutlet weak var btn_next:UIButton!
    @IBOutlet weak var btn_5050:UIButton!
    
    
    var numberQuestion:Int = -1
    var levelQuestion:Int = 0
    var listDataQuestion:[QuestionModel] = [QuestionModel]()     // mang lay list data
    var subList:[QuestionModel] = [QuestionModel]()              // list luu lai cac cau hoi theo tung dong
    var question2Array:[[QuestionModel]] = [[QuestionModel]]()   // mang 2 chieu lay du lieu theo level
    var shuffArray:[String] = [String]()                          // mang lay du lieu 4 dap an
    
    
    var listQuesHint:[QuestionModel] = [QuestionModel]()          // mang luu lai dap cau hoi de hien thi o HintQuesController
    var listCorrect:[String] = [String]()
    var listIncorrect:[String] = [String]()
    
    
    var checkAction:Bool = false            // bien luu da bam button chua
    var ansCorrect:String = ""              // bien luu dap an dung
    var countCorrect: Int = 0               // bien luu so cau dung
    var countIncorrect:Int = 0             // bien luu so cau sai
    var userMoney = 0                      // bien luu tien thuong
    var userPoint:Int = 0                // bien luu diemn
    
    //2 bien luu dap an 2 su tro giup 50:50
    var res5050_1:String = ""
    var res5050_2:String = ""
    
    var currentProgress: Float = 0.0        // bien luu ty le time
    var mTimer:Timer?
    var number:Int = 30                     // bien set thoi gian chay
    
    var achieveNumberQuestion:Int = 0      // bien dem so cau dung hien thi achieveViewController
    var achieveCorrect:Int = 0
    
    var checkSound: Int = 0
    var musicPlayer:MusicPlayer = MusicPlayer.shared
    var checkMoneyPoint:Int = 0
    override func viewWillAppear(_ animated: Bool) {
        
        if UserDefaults.standard.integer(forKey: "CheckMoneyPoint") == 0{
            UserDefaults.standard.setValue(1, forKey: "CheckMoneyPoint")
            checkMoneyPoint = UserDefaults.standard.integer(forKey: "CheckMoneyPoint")
        }
        if UserDefaults.standard.integer(forKey: "Point") == 0 && checkMoneyPoint == 1{
            UserDefaults.standard.setValue(30, forKey: "Point")
            userPoint = UserDefaults.standard.integer(forKey: "Point")
            labelPs.text = String(userPoint)
            
        } else {
            userPoint = UserDefaults.standard.integer(forKey: "Point")
            labelPs.text = String(userPoint)
            
        }
        if  UserDefaults.standard.integer(forKey: "Money") == 0  && checkMoneyPoint == 1{
            UserDefaults.standard.setValue(30, forKey: "Money")
            userMoney = UserDefaults.standard.integer(forKey: "Money")
            labelMoney.text = String(userMoney)
        } else{
            userMoney = UserDefaults.standard.integer(forKey: "Money")
            labelMoney.text = String(userMoney)
        }
        // luu diem hein thi achieveViewController
        if  UserDefaults.standard.integer(forKey: "achieveNumberQuestion") == 0 {
            UserDefaults.standard.setValue(0, forKey: "achieveNumberQuestion")
        }
        if  UserDefaults.standard.integer(forKey: "achieveCorrect") == 0 {
            UserDefaults.standard.setValue(0, forKey: "achieveCorrect")
        }
        checkSound = UserDefaults.standard.integer(forKey: "Sound")
        checkMoneyPoint = 2
        UserDefaults.standard.setValue(checkMoneyPoint, forKey: "CheckMoneyPoint")
    }

    override func viewDidDisappear(_ animated: Bool) {
        timerPase()
    }
    override func viewDidAppear(_ animated: Bool) {
        timerStart()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        achieveNumberQuestion = UserDefaults.standard.integer(forKey: "achieveNumberQuestion")
        achieveNumberQuestion += 1
        UserDefaults.standard.setValue(achieveNumberQuestion, forKey: "achieveNumberQuestion")
        
        numberQuestion += 1
        shuffArray.removeAll()
        
        number = 30
        currentProgress = 0.0
        
        timeCircle.setProgress(CGFloat(currentProgress), animated: true)
        timerStart()
        
        labelNumQues.text = "Level \(levelQuestion)"
        labelNumerQuestion.text = "\(numberQuestion+1)/10"
        viewOptionA.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        viewOptionB.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        viewOptionC.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        viewOptionD.backgroundColor = #colorLiteral(red: 0.8925680518, green: 0.8966992497, blue: 0.9067956805, alpha: 1)
        labelcheckTime.text = String(30)
        
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            labelNumQues.font = UIFont(name: "Chalkboard SE Bold", size: 38)
            labelNumerQuestion.font = UIFont.boldSystemFont(ofSize: 33)
            labelQuestion.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionA.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionB.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionC.font = UIFont.boldSystemFont(ofSize: 33)
            labelOptionD.font = UIFont.boldSystemFont(ofSize: 33)
            labelCorrect.font = UIFont.boldSystemFont(ofSize: 33)
            labelINCorrect.font = UIFont.boldSystemFont(ofSize: 33)
            labelMoney.font = UIFont.boldSystemFont(ofSize: 33)
            labelPs.font = UIFont.boldSystemFont(ofSize: 33)
            labelcheckTime.font = UIFont.boldSystemFont(ofSize: 30)
            
            viewOptionA.layer.cornerRadius = 20
            viewOptionB.layer.cornerRadius = 20
            viewOptionC.layer.cornerRadius = 20
            viewOptionD.layer.cornerRadius = 20
            
            btn_a.layer.cornerRadius = 15
            btn_b.layer.cornerRadius = 15
            btn_c.layer.cornerRadius = 15
            btn_d.layer.cornerRadius = 15
            
            let heightConstraintNext = NSLayoutConstraint(item: btn_next as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            let widthConstraintNext = NSLayoutConstraint(item: btn_next as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 100)
            btn_next.addConstraints([ widthConstraintNext, heightConstraintNext])
            
            let heightConstraint5050 = NSLayoutConstraint(item: btn_5050 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 83)
            let widthConstraint5050 = NSLayoutConstraint(item: btn_5050 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 83)
            btn_5050.addConstraints([ widthConstraint5050, heightConstraint5050])
            
            let heightConstraintClock = NSLayoutConstraint(item: btn_clock as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 83)
            let widthConstraintClock = NSLayoutConstraint(item: btn_clock as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 83)
            btn_clock.addConstraints([ widthConstraintClock, heightConstraintClock])
            
            let heightConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            let withConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            imageBack3.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            let withConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 80)
            imageSetting3.addConstraints([ heightConstraintSetting, withConstraintSetting])
        }else{
            labelNumQues.font = UIFont(name: "Chalkboard SE Bold", size: 30)
            labelQuestion.font = UIFont.boldSystemFont(ofSize: 20)
            labelNumerQuestion.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionA.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionB.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionC.font = UIFont.boldSystemFont(ofSize: 20)
            labelOptionD.font = UIFont.boldSystemFont(ofSize: 20)
            labelCorrect.font = UIFont.boldSystemFont(ofSize: 20)
            labelINCorrect.font = UIFont.boldSystemFont(ofSize: 20)
            labelMoney.font = UIFont.boldSystemFont(ofSize: 20)
            labelPs.font = UIFont.boldSystemFont(ofSize: 20)
            labelcheckTime.font = UIFont.boldSystemFont(ofSize: 20)
            
            viewOptionA.layer.cornerRadius = 15
            viewOptionB.layer.cornerRadius = 15
            viewOptionC.layer.cornerRadius = 15
            viewOptionD.layer.cornerRadius = 15
            
            btn_a.layer.cornerRadius = 10
            btn_b.layer.cornerRadius = 10
            btn_c.layer.cornerRadius = 10
            btn_d.layer.cornerRadius = 10
            
            let heightConstraintNext = NSLayoutConstraint(item: btn_next as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 60)
            let widthConstraintNext = NSLayoutConstraint(item: btn_next as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 60)
            btn_next.addConstraints([ widthConstraintNext, heightConstraintNext])
            
            let heightConstraint5050 = NSLayoutConstraint(item: btn_5050 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let widthConstraint5050 = NSLayoutConstraint(item: btn_5050 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            btn_5050.addConstraints([ widthConstraint5050, heightConstraint5050])
            
            let heightConstraintClock = NSLayoutConstraint(item: btn_clock as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let widthConstraintClock = NSLayoutConstraint(item: btn_clock as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            btn_clock.addConstraints([ widthConstraintClock, heightConstraintClock])
            
            let heightConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintBack = NSLayoutConstraint(item: imageBack3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageBack3.addConstraints([ heightConstraintBack, withConstraintBack])
            
            let heightConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            let withConstraintSetting = NSLayoutConstraint(item: imageSetting3 as Any, attribute: NSLayoutConstraint.Attribute.width, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: 50)
            imageSetting3.addConstraints([ heightConstraintSetting, withConstraintSetting])

        }
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(ImageBack3))
        imageBack3.addGestureRecognizer(tapGR)
        imageBack3.isUserInteractionEnabled = true
        
        let tapGR1 = UITapGestureRecognizer(target: self, action: #selector(ImageSetting3))
        imageSetting3.addGestureRecognizer(tapGR1)
        imageSetting3.isUserInteractionEnabled = true
        
        SqliteService.shared.getDataQuestion(){repond,error in
            if let repond = repond{
                self.listDataQuestion = repond
            }
        }
        
        

        for i in 1...25{
            subList.removeAll()
            for question in listDataQuestion  {
                if question.level == String(i)  {
                    subList.append(question)
                }
            }
            question2Array.append(subList)
        }
        
        if numberQuestion == 0{
            labelCorrect.text = String(0)
            labelINCorrect.text = String(0)
            
            question2Array[levelQuestion-1].shuffle()
            
        }
        //lay du lieu qua mang hien thi o ben hintQuestionViewController
        let questionModelHint:QuestionModel = QuestionModel.init(id: 0, question: "", option_a: "", option_b: "", option_c: "", option_d: "", right_answer: "", level: "")
        
        let questionNumberi:QuestionModel = question2Array[levelQuestion-1][numberQuestion]
        ansCorrect = questionNumberi.option_a
        listCorrect.append(ansCorrect)
        
        labelQuestion.text = questionNumberi.question
            
        shuffArray.append(questionNumberi.option_a)
        shuffArray.append(questionNumberi.option_b)
        shuffArray.append(questionNumberi.option_c)
        shuffArray.append(questionNumberi.option_d)
        shuffArray.shuffle()
        labelOptionA.text = shuffArray[0]
        labelOptionB.text = shuffArray[1]
        labelOptionC.text = shuffArray[2]
        labelOptionD.text = shuffArray[3]
        
        questionModelHint.question = questionNumberi.question
        questionModelHint.option_a = shuffArray[0]
        questionModelHint.option_b = shuffArray[1]
        questionModelHint.option_c = shuffArray[2]
        questionModelHint.option_d = shuffArray[3]
        questionModelHint.id = questionNumberi.id
        listQuesHint.append(questionModelHint)
        
        checkAction = false
        if checkAction == false {
                
            let gestureA = UITapGestureRecognizer(target: self, action:  #selector (self.ViewActionA))
            self.viewOptionA.isUserInteractionEnabled = true
            viewOptionA.addGestureRecognizer(gestureA)

            let gestureB = UITapGestureRecognizer(target: self, action:  #selector (self.ViewActionB))
            self.viewOptionB.isUserInteractionEnabled = true
            viewOptionB.addGestureRecognizer(gestureB)

            let gestureC = UITapGestureRecognizer(target: self, action:  #selector (self.ViewActionC))
            self.viewOptionC.isUserInteractionEnabled = true
            viewOptionC.addGestureRecognizer(gestureC)

            let gestureD = UITapGestureRecognizer(target: self, action:  #selector (self.ViewActionD))
            self.viewOptionD.isUserInteractionEnabled = true
            viewOptionD.addGestureRecognizer(gestureD)
            
            btn_5050.isUserInteractionEnabled = true
            btn_clock.isUserInteractionEnabled = true
            btn_next.isUserInteractionEnabled = true
        }
    }
    
    
    @objc func ImageBack3(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        dismiss(animated: true, completion: nil)
        countCorrect = 0
        countIncorrect = 0
    }
    @objc func ImageSetting3(tapGR: UITapGestureRecognizer){
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc: SettingViewController = storyboard.instantiateViewController(withIdentifier: "SettingViewController") as! SettingViewController
        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
        self.present(vc, animated: true, completion: nil)
    }
    

    @objc func ViewActionA(_ sender:UITapGestureRecognizer){
        if labelOptionA.text == ansCorrect{
            viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            
            countCorrect+=1
            userPoint+=5
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            //lay dap an dung
            listIncorrect.append("0")
            
            achieveCorrect = UserDefaults.standard.integer(forKey: "achieveCorrect")
            achieveCorrect += 1
            UserDefaults.standard.setValue(achieveCorrect, forKey: "achieveCorrect")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "CorrectMusic")
            }

        }else{
            viewOptionA.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
            if labelOptionB.text == ansCorrect{
                viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionC.text == ansCorrect{
                viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionD.text == ansCorrect{
                viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            countIncorrect+=1
            userPoint -= 2
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            // lay dap an sai
            listIncorrect.append("1")
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "IncorrectMusic")
            }
            
        }
        
        labelCorrect.text = String(countCorrect)
        labelINCorrect.text = String(countIncorrect)
                
        checkAction = true
        viewOptionA.isUserInteractionEnabled = false
        viewOptionB.isUserInteractionEnabled = false
        viewOptionC.isUserInteractionEnabled = false
        viewOptionD.isUserInteractionEnabled = false
        
        btn_5050.isUserInteractionEnabled = false
        btn_clock.isUserInteractionEnabled = false
        btn_next.isUserInteractionEnabled = false
        
        timerStop()
        
        if numberQuestion < 9{
            var itemSecond:Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    self.viewDidLoad()
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        } else{
            var itemSecond:Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    
                    let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let vc: ScoreViewController = storyboard.instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
                    vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
                    vc.hintCorrect = self.countCorrect
                    vc.hintLevelQuestion = self.levelQuestion
                    vc.questionScoreArray = self.listQuesHint
                    vc.listCorrectHint = self.listCorrect
                    vc.listIncorrectHint = self.listIncorrect
                    self.present(vc, animated: true, completion: nil)
                    
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        }
    }
    
    
    @objc func ViewActionB(_ sender:UITapGestureRecognizer){
        if labelOptionB.text == ansCorrect{
            viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            
            countCorrect+=1
            userPoint+=5
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            listIncorrect.append("0")
            
            achieveCorrect = UserDefaults.standard.integer(forKey: "achieveCorrect")
            achieveCorrect += 1
            UserDefaults.standard.setValue(achieveCorrect, forKey: "achieveCorrect")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "CorrectMusic")
            }

        }
        else{
            viewOptionB.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
            
            if labelOptionA.text == ansCorrect{
                viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionC.text == ansCorrect{
                viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionD.text == ansCorrect{
                viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            
            countIncorrect+=1
            userPoint -= 2
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            listIncorrect.append("2")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "IncorrectMusic")
            }
        }
        
        labelCorrect.text = String(countCorrect)
        labelINCorrect.text = String(countIncorrect)

        checkAction = true
        viewOptionA.isUserInteractionEnabled = false
        viewOptionB.isUserInteractionEnabled = false
        viewOptionC.isUserInteractionEnabled = false
        viewOptionD.isUserInteractionEnabled = false
        
        btn_5050.isUserInteractionEnabled = false
        btn_clock.isUserInteractionEnabled = false
        btn_next.isUserInteractionEnabled = false
        
        timerStop()
        
        if numberQuestion < 9{
            var itemSecond: Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    self.viewDidLoad()
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        }else{
            var itemSecond:Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    
                    let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let vc: ScoreViewController = storyboard.instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
                    vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
                    vc.hintCorrect = self.countCorrect
                    vc.hintLevelQuestion = self.levelQuestion
                    vc.questionScoreArray = self.listQuesHint
                    vc.listCorrectHint = self.listCorrect
                    vc.listIncorrectHint = self.listIncorrect
                    self.present(vc, animated: true, completion: nil)
                    
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        }
       
    }
    
    
    @objc func ViewActionC(_ sender:UITapGestureRecognizer){
        if labelOptionC.text == ansCorrect{
            viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            
            countCorrect+=1
            userPoint+=5
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            listIncorrect.append("0")
            
            achieveCorrect = UserDefaults.standard.integer(forKey: "achieveCorrect")
            achieveCorrect += 1
            UserDefaults.standard.setValue(achieveCorrect, forKey: "achieveCorrect")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "CorrectMusic")
            }

        }
        else{
            viewOptionC.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
            
            if labelOptionA.text == ansCorrect{
                viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionB.text == ansCorrect{
                viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionD.text == ansCorrect{
                viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            countIncorrect+=1
            userPoint -= 2
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            listIncorrect.append("3")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "IncorrectMusic")
            }
        }
        
        labelCorrect.text = String(countCorrect)
        labelINCorrect.text = String(countIncorrect)
          
        checkAction = true
        viewOptionA.isUserInteractionEnabled = false
        viewOptionB.isUserInteractionEnabled = false
        viewOptionC.isUserInteractionEnabled = false
        viewOptionD.isUserInteractionEnabled = false
        
        btn_5050.isUserInteractionEnabled = false
        btn_clock.isUserInteractionEnabled = false
        btn_next.isUserInteractionEnabled = false
        
        timerStop()
        
        if numberQuestion < 9{
            var itemSecond: Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    self.viewDidLoad()
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        }else{
            var itemSecond:Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    
                    let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let vc: ScoreViewController = storyboard.instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
                    vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
                    vc.hintCorrect = self.countCorrect
                    vc.hintLevelQuestion = self.levelQuestion
                    vc.questionScoreArray = self.listQuesHint
                    vc.listCorrectHint = self.listCorrect
                    vc.listIncorrectHint = self.listIncorrect
                    self.present(vc, animated: true, completion: nil)
                    
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        }
    }
    
    
    @objc func ViewActionD(_ sender:UITapGestureRecognizer){
        if labelOptionD.text == ansCorrect{
            viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            
            countCorrect+=1
            userPoint+=5
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            listIncorrect.append("0")
            
            achieveCorrect = UserDefaults.standard.integer(forKey: "achieveCorrect")
            achieveCorrect += 1
            UserDefaults.standard.setValue(achieveCorrect, forKey: "achieveCorrect")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "CorrectMusic")
            }

        }
        else{
            viewOptionD.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1)
            if labelOptionA.text == ansCorrect{
                viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionB.text == ansCorrect{
                viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionC.text == ansCorrect{
                viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            countIncorrect+=1
            userPoint -= 2
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            listIncorrect.append("4")
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "IncorrectMusic")
            }
        }
        
        labelCorrect.text = String(countCorrect)
        labelINCorrect.text = String(countIncorrect)

        
        checkAction = true
        viewOptionA.isUserInteractionEnabled = false
        viewOptionB.isUserInteractionEnabled = false
        viewOptionC.isUserInteractionEnabled = false
        viewOptionD.isUserInteractionEnabled = false
        
        btn_5050.isUserInteractionEnabled = false
        btn_clock.isUserInteractionEnabled = false
        btn_next.isUserInteractionEnabled = false
        
        timerStop()
        
        if numberQuestion < 9{
            var itemSecond: Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    self.viewDidLoad()
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        } else{
            var itemSecond:Float = 0
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                if itemSecond == 1 {
                    
                    let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let vc: ScoreViewController = storyboard.instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
                    vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
                    vc.hintCorrect = self.countCorrect
                    vc.hintLevelQuestion = self.levelQuestion
                    vc.questionScoreArray = self.listQuesHint
                    vc.listCorrectHint = self.listCorrect
                    vc.listIncorrectHint = self.listIncorrect
                    self.present(vc, animated: true, completion: nil)
                    
                    timer.invalidate()
                }
                itemSecond = itemSecond + 1
            }
        }
    }
    
    
    @IBAction func btn_Clock(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if  userMoney < 4 {
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "PopUpViewController") as? PopUpViewController else { return }
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .crossDissolve
            present(vc, animated: true)
        }else{
            number = 30
            
            currentProgress = 0.0
            
            timeCircle.setProgress(CGFloat(currentProgress), animated: true)
            timerStart()
            labelcheckTime.text = String(30)
            
            userMoney -= 4
            UserDefaults.standard.setValue(userMoney, forKey: "Money")
            labelMoney.text = String(userMoney)
        }
        
        
    }
    
    
    @IBAction func btn_next(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if userMoney < 6 {
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "PopUpViewController") as? PopUpViewController else { return }
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .crossDissolve
            present(vc, animated: true)

        }else{
            timerStop()
            
            if labelOptionA.text == ansCorrect{
                viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionB.text == ansCorrect{
                viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionC.text == ansCorrect{
                viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionD.text == ansCorrect{
                viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            countCorrect+=1
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "CorrectMusic")
            }
            
            achieveCorrect = UserDefaults.standard.integer(forKey: "achieveCorrect")
            achieveCorrect += 1
            UserDefaults.standard.setValue(achieveCorrect, forKey: "achieveCorrect")
            
            userPoint += 5
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            userMoney -= 6
            UserDefaults.standard.setValue(userMoney, forKey: "Money")
            labelMoney.text = String(userMoney)
            
            labelCorrect.text = String(countCorrect)
            labelINCorrect.text = String(countIncorrect)

            checkAction = true
            viewOptionA.isUserInteractionEnabled = false
            viewOptionB.isUserInteractionEnabled = false
            viewOptionC.isUserInteractionEnabled = false
            viewOptionD.isUserInteractionEnabled = false
            
            btn_5050.isUserInteractionEnabled = false
            btn_clock.isUserInteractionEnabled = false
            btn_next.isUserInteractionEnabled = false
            
            listIncorrect.append("0")
            
            if numberQuestion < 9{
                var itemSecond: Float = 0
                Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                    if itemSecond == 1 {
                        self.viewDidLoad()
                        timer.invalidate()
                    }
                    itemSecond = itemSecond + 1
                }
            } else{
                var itemSecond:Float = 0
                Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                    if itemSecond == 1 {
                        
                        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc: ScoreViewController = storyboard.instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
                        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
                        vc.hintCorrect = self.countCorrect
                        vc.hintLevelQuestion = self.levelQuestion
                        vc.questionScoreArray = self.listQuesHint
                        vc.listCorrectHint = self.listCorrect
                        vc.listIncorrectHint = self.listIncorrect
                        self.present(vc, animated: true, completion: nil)
                        
                        timer.invalidate()
                    }
                    itemSecond = itemSecond + 1
                }
            }

        }
        
    }
    
    
    
    @IBAction func btn_5050(_ sender: Any) {
        if checkSound == 1{
            musicPlayer.playSoundEffect(soundEffect: "TouchMusic")
        }
        if userMoney < 4 {
            guard let vc = storyboard?.instantiateViewController(withIdentifier: "PopUpViewController") as? PopUpViewController else { return }
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .crossDissolve
            present(vc, animated: true)

        } else{
            shuffArray.shuffle()
            
            for i in 0...shuffArray.count {
                if shuffArray[i] == ansCorrect{
                    shuffArray.remove(at: i)
                    break
                }
            }
            userMoney -= 4
            UserDefaults.standard.setValue(userMoney, forKey: "Money")
            labelMoney.text = String(userMoney)
            
            res5050_1 = shuffArray[0]
            res5050_2 = shuffArray[1]
            
            if labelOptionA.text == res5050_1 || labelOptionA.text == res5050_2 {
                labelOptionA.text = ""
                viewOptionA.isUserInteractionEnabled = false
            }
            if labelOptionB.text == res5050_1 || labelOptionB.text == res5050_2 {
                labelOptionB.text = ""
                viewOptionB.isUserInteractionEnabled = false
            }
            if labelOptionC.text == res5050_1 || labelOptionC.text == res5050_2 {
                labelOptionC.text = ""
                viewOptionC.isUserInteractionEnabled = false
            }
            if labelOptionD.text == res5050_1 || labelOptionD.text == res5050_2 {
                labelOptionD.text = ""
                viewOptionD.isUserInteractionEnabled = false
            }
            btn_5050.isUserInteractionEnabled = false
        }
    }
    
    
    
    @objc func timerCallback(){
        number -= 1
        currentProgress = Float.minimum(1.0, currentProgress + 0.033)
        timeCircle.setProgress(CGFloat(currentProgress), animated: true)
        if number <= 0 {
            
            timerStop()
            
            if labelOptionA.text == ansCorrect{
                viewOptionA.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionB.text == ansCorrect{
                viewOptionB.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionC.text == ansCorrect{
                viewOptionC.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            if labelOptionD.text == ansCorrect{
                viewOptionD.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0, alpha: 1)
            }
            
            if checkSound == 1 {
                musicPlayer.playSoundEffect(soundEffect: "IncorrectMusic")
            }
            
            countIncorrect+=1
            userPoint -= 2
            UserDefaults.standard.setValue(userPoint, forKey: "Point")
            labelPs.text = String(UserDefaults.standard.integer(forKey: "Point"))
            
            labelCorrect.text = String(countCorrect)
            labelINCorrect.text = String(countIncorrect)

            checkAction = true
            viewOptionA.isUserInteractionEnabled = false
            viewOptionB.isUserInteractionEnabled = false
            viewOptionC.isUserInteractionEnabled = false
            viewOptionD.isUserInteractionEnabled = false
            
            listIncorrect.append("0")
            
            if numberQuestion < 9{
                var itemSecond: Float = 0
                Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                    if itemSecond == 1 {
                        self.viewDidLoad()
                        timer.invalidate()
                    }
                    itemSecond = itemSecond + 1
                }
            }
            else{
                var itemSecond:Float = 0
                Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                    if itemSecond == 1 {
                        
                        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc: ScoreViewController = storyboard.instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
                        vc.modalPresentationStyle = .fullScreen //or .overFullScreen for transparency
                        vc.hintCorrect = self.countCorrect
                        vc.hintLevelQuestion = self.levelQuestion
                        vc.questionScoreArray = self.listQuesHint
                        vc.listCorrectHint = self.listCorrect
                        vc.listIncorrectHint = self.listIncorrect
                        self.present(vc, animated: true, completion: nil)
                        
                        timer.invalidate()
                    }
                    itemSecond = itemSecond + 1
                }
            }
        }
        
        labelcheckTime.text = String(number)
        
    }
    func timerStart(){
        if let timer = mTimer {
            if !timer.isValid {
                mTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerCallback), userInfo: nil, repeats: true)
            }
        }else{
            mTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerCallback), userInfo: nil, repeats: true)
        }
    }
    
    func timerStop(){
       if let timer = mTimer {
            if(timer.isValid){
                timer.invalidate()
            }
        }
        number = 0
    }
    func timerPase(){
        mTimer?.invalidate()
    }
}
