//
//  SQLiteService.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 06/07/2021.
//

import Foundation
import SQLite3
import SQLite
class SqliteService:NSObject {
    static let shared: SqliteService = SqliteService()
    var DatabaseRoot:Connection?
    var listDataQuestion:[QuestionModel] = [QuestionModel]()
    func loadInit(linkPath:String){
        do {
            self.DatabaseRoot = try Connection (linkPath)
        } catch {
            print(error)
        }
    }
    
    func getDataQuestion(closure: @escaping (_ response: [QuestionModel]?, _ error: Error?) -> Void) {
        let users1 = Table("questions_list")
        let id1 = Expression<Int>("id")
        let question1 = Expression<String>("question")
        let option_a1 = Expression<String?>("option_a")
        let option_b1 = Expression<String>("option_b")
        let option_c1 = Expression<String>("option_c")
        let option_d1 = Expression<String>("option_d")
        let right_answer1 = Expression<String>("right_answer")
        let level1 = Expression<String>("level")
        listDataQuestion.removeAll()
        if let DatabaseRoot = DatabaseRoot{
            do{
                for user in try DatabaseRoot.prepare(users1) {
                    listDataQuestion.append(QuestionModel(id: Int(user[id1]), question: user[question1], option_a: user[option_a1] ?? "", option_b: user[option_b1], option_c: user[option_c1], option_d: user[option_d1], right_answer: user[right_answer1], level:user[level1]))
                }
            } catch  {
            }
        }
        closure(listDataQuestion, nil)
        
    }
}

