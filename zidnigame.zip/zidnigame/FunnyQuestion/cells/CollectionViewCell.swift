//
//  CollectionViewCell.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 06/07/2021.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    //test commit
}
