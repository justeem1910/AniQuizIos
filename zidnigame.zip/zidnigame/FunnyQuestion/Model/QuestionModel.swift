//
//  Question.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 06/07/2021.
//

import Foundation
import SQLite3

class  QuestionModel {
    var id:Int = 0
    var level: String = ""
    var right_answer: String = ""
    var question:String = ""
    var option_a:String = ""
    var option_b:String = ""
    var option_c:String = ""
    var option_d:String = ""
    
    init(id:Int, question:String, option_a:String, option_b:String, option_c:String, option_d:String, right_answer:String, level: String) {
        self.id = id
        self.question = question
        self.option_a = option_a
        self.option_b = option_b
        self.option_c = option_c
        self.option_d = option_d
        self.right_answer = right_answer
        self.level = level
    }
    
}
