//
//  Image.swift
//  FunnyQuestion
//
//  Created by Hoang Long on 01/06/2021.
//

import Foundation
